#include "header.h"
#include<bits/stdc++.h>

using namespace std;

void cwd_func(char cwd[]){
    cout << cwd << '\n';
}